# DLC-Assignment01
Digital logic circuit II / assignment

Implement 2 to 1 Multiplexer
